// You can add interactivity later
console.log("Jose Electrofix site loaded successfully!");